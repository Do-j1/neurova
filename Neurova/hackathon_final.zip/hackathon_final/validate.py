"""Validate output schema and preservation of input IDs/questions."""
import json
from pathlib import Path
root=Path(__file__).resolve().parent
source=json.loads((root/'questions.json').read_text(encoding='utf-8-sig'))
output=json.loads((root/'answers.json').read_text(encoding='utf-8-sig'))
assert len(source['chats'])==len(output['chats']),'chat count mismatch'
count=0
for a,b in zip(source['chats'],output['chats']):
    assert a['chat_id']==b['chat_id'],'chat id mismatch'
    assert len(a['messages'])==len(b['messages']),'message count mismatch'
    for m,n in zip(a['messages'],b['messages']):
        assert m['message_id']==n['message_id'] and m['question']==n['question'],'message mismatch'
        assert isinstance(n.get('answer'),str) and n['answer'].strip(),'missing answer'
        assert isinstance(n.get('contexts'),list) and all(isinstance(x,str) for x in n['contexts']),'bad contexts'
        count+=1
print(f'PASS: {len(output["chats"])} chats, {count} messages, valid answers.json')
