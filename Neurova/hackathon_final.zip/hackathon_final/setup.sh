#!/usr/bin/env bash
set -e
cd "$(dirname "$0")"
if ! command -v ollama >/dev/null; then
  echo "Ollama is not installed. Ask the organizer to provide it."; exit 1
fi
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
echo "Check models with: ollama list"
echo "The search engine requires bge-m3 in addition to the official chat model."
echo "Run: bash run.sh"
