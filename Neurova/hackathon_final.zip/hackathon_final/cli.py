#!/usr/bin/env python3
"""Minimal terminal interface for the local document assistant."""
import os
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from src.pipeline import answer_question, get_available_models, select_best_model
from src.search import get_indexed_summary, ingest_directory, clear_collection


def ingest():
    folder = ROOT / "data"
    print("Indexing documents...")
    start = time.time()
    # Clear first: removed files must never remain searchable.
    # If indexing fails, re-run /ingest after fixing the problem.
    clear_collection()
    results = ingest_directory(folder)
    for name, count in results.items():
        print(f"  {name}: {count}")
    summary = get_indexed_summary()
    print(f"Indexed: {len(summary['sources'])} documents, {summary['total_chunks']} chunks ({time.time()-start:.1f}s)\n")


def main():
    model = select_best_model()
    summary = get_indexed_summary()
    print("AI Document Assistant")
    print(f"Model: {model}")
    print(f"Documents: {len(summary['sources'])} | Chunks: {summary['total_chunks']}")
    print("Commands: /ingest, /stats, /models, /help, /exit\n")
    while True:
        try:
            question = input("Question > ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\nBye")
            return
        if not question:
            continue
        command = question.lower()
        if command in ("/exit", "/quit"):
            print("Bye")
            return
        if command == "/help":
            print("/ingest: rebuild index | /stats: index info | /models: choose model | /exit: quit\n")
            continue
        if command == "/ingest":
            try:
                ingest()
            except Exception as e:
                print(f"Indexing failed: {e}\n")
            continue
        if command == "/stats":
            stats = get_indexed_summary()
            print(f"Documents: {len(stats['sources'])} | Chunks: {stats['total_chunks']}")
            for name, count in stats["sources"].items():
                print(f"  {name}: {count}")
            print()
            continue
        if command == "/models":
            models = get_available_models()
            if not models:
                print("No Ollama chat models detected.\n")
                continue
            for i, name in enumerate(models, 1):
                print(f"  {i}. {name}")
            choice = input("Model number (Enter to cancel): ").strip()
            if choice.isdigit() and 1 <= int(choice) <= len(models):
                model = models[int(choice)-1]
            print(f"Model: {model}\n")
            continue
        try:
            print("Thinking...")
            result = answer_question(question, model=model, k=4)
            print(f"\nAnswer: {result['answer']}")
            if result.get("enough_info"):
                sources = result.get("sources", [])
                if sources:
                    labels = []
                    for source in sources:
                        label = source["source"]
                        if source.get("page"):
                            label += f" (p. {source['page']})"
                        if label not in labels:
                            labels.append(label)
                    print("Retrieved context: " + ", ".join(labels))
            if result.get("error"):
                print("Check Ollama and installed models.")
            print(f"Time: {result.get('latency', 0):.1f}s\n")
        except Exception as e:
            print(f"Error: {e}\n")


if __name__ == "__main__":
    main()
