#!/usr/bin/env python3
"""
Government Services Chatbot  -  AI Future 26 (42 Irbid)

    python main.py questions.json   ->   answers.json

Design (stdlib only, works offline, no vector DB, no embedding model):

1. DATA    : every service file is parsed into its 9 official fields
             (menu junk removed, typos fixed, facts untouched).  A "context"
             is one field of one service, e.g.
             "تجديد دفتر العائلة - الزمن المستغرق لتقديم الخدمة: 45 دقيقة".
2. ROUTING : the question (Arabic / dialect) is mapped to (document, situation)
             pairs with lexicons  -> exactly the right service file(s) are
             picked, so look-alike services never get mixed up.
             Follow-up messages inherit the pair from the previous message.
             Unknown topic -> out of scope.  Missing document / situation
             -> a clarifying question.  Topic questions with no service words
             ("who becomes head of family?") -> BM25 over all fields.
3. FIELDS  : the question intent (fees / time / documents / place / ...) picks
             which fields of those services go to the model (notes are always
             included for fees/documents/conditions because facts hide there).
4. MODEL   : ONE short call to the Ollama model per message with only those
             fields, num_ctx set explicitly, temperature 0.  The model also
             writes refusals and clarifying questions.
5. SAFETY  : every message is wrapped in try/except, the file is rewritten
             after each message, and an extractive fallback answer is used if
             Ollama fails, so answers.json is always complete and valid.
"""
import json
import math
import os
import re
import sys
import time
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parent
DATA_DIR = ROOT / "data"
MODEL = os.getenv("HACKATHON_MODEL", "command-r7b-arabic:7b")
OLLAMA = os.getenv("OLLAMA_HOST", "http://127.0.0.1:11434")
if not OLLAMA.startswith("http"):
    OLLAMA = "http://" + OLLAMA
NUM_CTX = int(os.getenv("NUM_CTX", "2560"))
MAX_CTX_CHARS = 2600

# --------------------------------------------------------------------------
# Normalisation helpers
# --------------------------------------------------------------------------
_DIGITS = str.maketrans("٠١٢٣٤٥٦٧٨٩۰۱۲۳۴۵۶۷۸۹", "01234567890123456789")
_CHARMAP = str.maketrans({"أ": "ا", "إ": "ا", "آ": "ا", "ٱ": "ا", "ى": "ي", "ة": "ه",
                          "ئ": "ي", "ؤ": "و", "پ": "ب", "ڤ": "ف", "چ": "ج", "گ": "ك"})


def norm(s):
    s = (s or "").translate(_DIGITS)
    s = re.sub(r"[\u064B-\u065F\u0670\u0640\u200B-\u200F\uFEFF]", "", s)
    s = s.replace("ء", "").translate(_CHARMAP).lower()
    s = re.sub(r"[^\w\s]|_", " ", s)
    return re.sub(r"\s+", " ", s).strip()


SYN = {"توفي": "وفاه", "توفى": "وفاه", "متوفي": "وفاه", "مات": "وفاه", "ماتت": "وفاه",
       "توفيت": "وفاه", "جوز": "زوج", "جوزها": "زوج", "جوزي": "زوج", "زوجها": "زوج",
       "اولاد": "ابناء", "ولاد": "ابناء", "ولادي": "ابناء", "اولادي": "ابناء",
       "برا": "خارج", "بره": "خارج", "فلوس": "رسوم", "مصاري": "رسوم", "تكلفه": "رسوم",
       "سعر": "رسوم", "اغلي": "رسوم", "ارخص": "رسوم", "مبلغ": "رسوم", "ثمن": "رسوم"}

_PREFIXES = ("وبال", "ولل", "وال", "بال", "كال", "فال", "لل", "ال", "و", "ب", "ل", "ف")
_SUFFIXES = ("ها", "هم", "ات", "ون", "ين", "ان", "ه", "ي")


def stem(tok):
    tok = SYN.get(tok, tok)
    for p in _PREFIXES:
        if tok.startswith(p) and len(tok) - len(p) >= 3:
            tok = tok[len(p):]
            break
    for sfx in _SUFFIXES:
        if tok.endswith(sfx) and len(tok) - len(sfx) >= 3:
            tok = tok[:-len(sfx)]
            break
    return tok


def stems(text):
    return [stem(t) for t in norm(text).split()]


# --------------------------------------------------------------------------
# 1. Data: parse the service files into fields
# --------------------------------------------------------------------------
FIELD_HEADERS = [
    ("audience", "الفئة المستفيدة", "الفئة المستفيدة"),
    ("places", "أماكن تقديم الخدمة", "أماكن تقديم الخدمة"),
    ("conditions", "شروط تقديم الخدمة", "شروط تقديم الخدمة"),
    ("docs", "الوثائق المطلوبة للحصول على الخدمة", "الوثائق المطلوبة"),
    ("procedure", "إجراءات تقديم الخدمة", "إجراءات تقديم الخدمة"),
    ("time", "الزمن المستغرق لتقديم الخدمة", "الزمن المستغرق لتقديم الخدمة"),
    ("partners", "شركاء الخدمة", "شركاء الخدمة"),
    ("notes", "ملاحظات", "ملاحظات"),
    ("fees", "الرسوم", "الرسوم"),
]
LABEL = {k: lab for k, _, lab in FIELD_HEADERS}
_HDR_NORM = [(k, norm(h)) for k, h, _ in FIELD_HEADERS]

SERVICES = {
    "passport_first_issue": ("passport", "first", "جواز سفر عادي لأول مرة"),
    "passport_renewal": ("passport", "renewal", "تجديد جواز السفر"),
    "passport_lost": ("passport", "lost", "جواز سفر بدل فاقد"),
    "passport_damaged": ("passport", "damaged", "جواز سفر بدل تالف"),
    "family_book_first_issue": ("family", "first", "دفتر عائلة لأول مرة"),
    "family_book_renewal": ("family", "renewal", "تجديد دفتر العائلة"),
    "family_book_lost": ("family", "lost", "دفتر عائلة بدل فاقد"),
    "family_book_damaged": ("family", "damaged", "دفتر عائلة بدل تالف"),
    "id_card_first_issue": ("id", "first", "إصدار البطاقة الذكية لأول مرة"),
    "id_card_renewal": ("id", "renewal", "تجديد البطاقة الذكية"),
    "id_card_lost": ("id", "lost", "بطاقة ذكية بدل فاقد"),
    "id_card_damaged": ("id", "damaged", "بطاقة ذكية بدل تالف"),
}
DOC_NAME = {"passport": "جواز السفر", "family": "دفتر العائلة", "id": "البطاقة الذكية"}
SIT_NAME = {"first": "لأول مرة", "renewal": "تجديد", "lost": "بدل فاقد", "damaged": "بدل تالف"}
SITS = ["first", "renewal", "lost", "damaged"]

TYPOS = {"إ‘حصاءات": "إحصاءات", "الوئيقة": "الوثيقة", "الوئيفة": "الوثيقة", "فسم": "قسم",
         "متلفي": "متلقي", "دنانبر": "دنانير", "؟أمين": "أمين", "االدفتر": "الدفتر",
         "بطافات": "بطاقات", "مشرحات": "مشروحات", "لادخال": "لإدخال"}


def clean_value(text):
    for a, b in TYPOS.items():
        text = text.replace(a, b)
    text = text.replace("]", "").replace("\t", " ")
    return re.sub(r"\s+", " ", text).strip()


def parse_service(path):
    fields, cur, buf = {}, None, []

    def flush():
        if cur is not None:
            val = clean_value(" ".join(buf))
            if val:
                fields[cur] = (fields[cur] + " " + val) if cur in fields else val

    for line in path.read_text(encoding="utf-8-sig", errors="replace").splitlines():
        ln = norm(line)
        hit = None
        for key, hn in _HDR_NORM:
            if ln.startswith(hn):
                hit = (key, hn)
                break
        if hit:
            flush()
            cur, buf = hit[0], []
            # keep what follows the header on the same line
            m = re.match(r"\s*" + r"\s*".join(map(re.escape, dict((k, h) for k, h, _ in FIELD_HEADERS)[hit[0]].split())) + r"\s*", line)
            rest = line[m.end():] if m else ""
            if not m:  # spelling differences: cut after first tab / run of spaces
                parts = re.split(r"\t+|\s{2,}", line.strip(), maxsplit=1)
                rest = parts[1] if len(parts) > 1 else ""
            if rest.strip():
                buf.append(rest)
        elif cur is not None and line.strip():
            buf.append(line.strip())
    flush()
    return fields


def load_services():
    svcs = []
    for name, (doc, sit, title) in SERVICES.items():
        p = DATA_DIR / f"{name}.txt"
        if not p.exists():
            print(f"WARNING: missing {p}", file=sys.stderr)
            continue
        f = parse_service(p)
        svcs.append({"name": name, "doc": doc, "sit": sit, "title": title, "fields": f})
    return svcs


def ctx_text(svc, key):
    return f"{svc['title']} - {LABEL[key]}: {svc['fields'][key]}"


# --------------------------------------------------------------------------
# 2. Query understanding (document / situation / intent)
# --------------------------------------------------------------------------
PRE_REMOVE = [r"دفتر خدمه العلم", r"دفتر الخدمه", r"خدمه العلم",
              r"بطاق(?:ه|ات) (?:احصاءات |احصايات )?الجسور(?: الصفراء)?", r"بطاقه احصاءات",
              r"(?:ال)?هويات? (?:ال)?مقدسي(?:ه|ات)?", r"(?:ال)?بطاقه (?:ال)?فلسطينيه"]
DOC_PATS = {"passport": r"جواز|باسبور|بسبور|passport|جوازات",
            "family": r"دفتر|دفاتر|عايل|عيل|كتيب",
            "id": r"بطاق|هوي|identity|ايدي|^id$"}
_P = r"^(?:و|ب|ل|ف|ك|ال|لل|بال|وال|ا|ت|ي|ن)?"
S_PATS = {"renewal": _P + r"(?:جدد|تجدد|تجديد|منتهي|انتهت|انتهي|خلص|صلاحي|تمديد)",
          "lost": _P + r"(?:فاقد|فقد|ضاع|ضايع|ضيع|مفقود|سرق|ضياع)",
          "damaged": _P + r"(?:تالف|تلف|خرب|ممزق|تمزق|مقطوع|اتلف|متضرر|تضرر|محروق)"}
WEAK_FIRST = r"اصدار|استخراج|اطلع|طلع|جديده?$|اطلاع|اعمل"
TOPIC_DOC = {"family": r"رب الاسره|ربا للاسره|زوجات|مطلقه|عقد الزواج|الزواج|الطلاق|فتح قيد|قيد مدني|قيد الاسره",
             "id": r"زمره الدم|زمره دم|قزحيه|الرقم السري|فحص طبي",
             "passport": r"حجه وصايه|حجه ولايه|حجه الوصايه|حجه الولايه|وثيقه سفر|السفر"}
COMPARE = r"ولا |مقابل|الفرق|بين |ايهما|اغلي|ارخص|اسرع|ابطا|كلا|كلاهما|مع بعض|قارن"

INTENT_PATS = {
    "fees": r"رسوم|رسم |تكلف|يكلف|بكلف|كلف|بدفع|ادفع|دفع|سعر|ثمن|غرام|كفال|مبلغ|دينار|اغلي|ارخص|تعهد|بكفي|بتكلف",
    "time": r"يستغرق|مده|مدت|وقت|ياخد|ياخذ|ياخذ|يطول|تاخذ|تاخد|كم يوم|كم ساعه|كم دقيق|اسرع|ابطا|بسرعه",
    "places": r"وين|اين|مكان|اماكن|مكتب|سفار|قنصل|بره|برا|خارج|اقدم|اطلع",
    "docs": r"اوراق|وثايق|وثائق|مستند|مطلوب|يلزم|بلزم|لازم|احتاج|بحتاج|احضر|اجيب|احمل|صور|ورق|اوراقي",
    "conditions": r"شرط|شروط|يحق|مين بقدر|مين يقدر|مين يقدم|ولي|وصي|وصايه|ولايه|قاصر|موافقه|زوج|عمر|سنه|سنين|حضور|شخصيا|وكاله|توكيل|تفويض|اب |ام ",
    "procedure": r"خطوات|اجراءات|طريقه|كيف|مراحل",
    "whatdo": r"شو بعمل|شو اعمل|شو بصير|شو الحل|شو الاجراء|ماذا افعل|شو لازم اعمل|بعمل ايش",
    "partners": r"جهات|شركاء|شريك",
    "notes": r"وفاه|غرامه|مهله|خلال|تاخير|تاخرت|اسبوع|اشهر|لجنه|تحقيق|متعمد|ثالثه|ثانيه|مستعجل|رب الاسره|اكبر|طلاق|ابلاغ|يبلغ|تعدد|زوجات",
}
INTENT_FIELDS = {"fees": ["fees", "notes"], "time": ["time"], "places": ["places"],
                 "docs": ["docs", "notes"], "conditions": ["conditions", "notes"],
                 "procedure": ["procedure"], "whatdo": ["docs", "fees", "notes"], "partners": ["partners"], "notes": ["notes"]}
DEFAULT_FIELDS = ["fees", "docs", "notes"]
_ANY_LEX = re.compile("|".join([*DOC_PATS.values(), *S_PATS.values(), *INTENT_PATS.values(), WEAK_FIRST]))

STOP = set(norm(w) for w in """كم قديش شو ايش اش ما ماذا هل وين اين كيف بدي بدك بده عن من في على الي الى انا اني لو اذا ان عشان
علشان لان يعني ممكن بقدر اقدر بكون هاد هاي هذا هذه هادا ده دي و او ولا لا مش مو طيب طب اه صح لما بعد قبل عند عندي عندك
معي معاي مع اللي التي الذي ايه انو انه كان كانت يكون بس كل كمان تاني ثاني حدا احد شخص مين اي ايها ايهما هو هي هم نفس
سؤال ممكن لازم رجاء بليز يا اخ اخي استاذ عمري عمره""".split())


CONTENT_STOP = set(norm(w) for w in "سفر ذكيه شخصيه مدنيه عايله دائره احوال خدمه خدمات الخدمه طلب الطلب كنت كان".split())


def detect(question):
    """-> dict(pairs, docs, sits, intents, tokens)"""
    q = norm(question)
    for pat in PRE_REMOVE:
        q = re.sub(pat, " ", q)
    toks = q.split()
    docs, sits = [], []          # (index, value)
    for i, t in enumerate(toks):
        for d, pat in DOC_PATS.items():
            if re.search(pat, t):
                docs.append((i, d, t.startswith("و") and re.search(pat, t[1:]) is not None or (i > 0 and toks[i - 1] == "و")))
                break
    for i, t in enumerate(toks):
        for s, pat in S_PATS.items():
            if re.search(pat, t):
                sits.append((i, s))
                break
        else:
            nxt = toks[i + 1] if i + 1 < len(toks) else ""
            if (t in ("لاول", "الاول", "اول", "لاولي") and nxt.startswith("مر")) or t == "لاول":
                sits.append((i, "first"))
    if not sits:
        for i, t in enumerate(toks):
            if re.search(WEAK_FIRST, t):
                sits.append((i, "first"))
                break
    if not sits and "بدل" in toks:
        i = toks.index("بدل")
        sits += [(i, "lost"), (i, "damaged")]

    pairs = []
    if docs and sits:
        paired_docs = set()
        for si, s in sits:
            best = min(docs, key=lambda d: (abs(d[0] - si), d[0] > si))
            if abs(best[0] - si) <= 6:
                pairs.append((best[1], s))
                paired_docs.add(best[0])
            else:
                pairs += [(d[1], s) for d in docs]
                paired_docs |= {d[0] for d in docs}
        # coordinated documents ("... وجواز السفر") share the situations of their neighbour
        only_sits = {s for _, s in sits}
        for di, d, conj in docs:
            if di in paired_docs:
                continue
            if conj or (len(only_sits) == 1 and re.search(COMPARE, q + " ")):
                pairs += [(d, s) for s in only_sits]
        pairs = list(dict.fromkeys(pairs))
    doc_set = list(dict.fromkeys(d for _, d, _ in docs))
    if docs and not pairs:
        pairs = [(d, None) for d in doc_set]
    sit_set = list(dict.fromkeys(s for _, s in sits))
    if not docs and sits:
        pairs = [(None, s) for s in sit_set]
    if not docs:                       # infer document from topic words
        for d, pat in TOPIC_DOC.items():
            if re.search(pat, q):
                doc_set.append(d)
                pairs = [(d, s) for s in sit_set] if sit_set else [(d, None)]
                break
    intents = [k for k, pat in INTENT_PATS.items() if re.search(pat, q + " ")]
    content = [stem(t) for t in toks if t not in STOP and stem(t) not in STOP and len(t) >= 3
               and not _ANY_LEX.search(t) and not t.isdigit() and stem(t) not in CONTENT_STOP]
    return {"pairs": pairs, "docs": doc_set, "sits": sit_set, "intents": intents, "content": content, "q": q}


# --------------------------------------------------------------------------
# BM25 over fields (used only when no service words are present)
# --------------------------------------------------------------------------
class Index:
    def __init__(self, svcs):
        self.svcs = svcs
        self.items = []
        for s in svcs:
            for k, v in s["fields"].items():
                self.items.append((s, k, stems(v)))
        self.N = len(self.items)
        self.avg = sum(len(t) for _, _, t in self.items) / max(1, self.N)
        self.df = {}
        for _, _, toks in self.items:
            for w in set(toks):
                self.df[w] = self.df.get(w, 0) + 1
        self.vocab = set(self.df)

    def search(self, q_stems, allowed_docs=None, topn=4):
        scored = []
        for s, k, toks in self.items:
            if allowed_docs and s["doc"] not in allowed_docs:
                continue
            if k in ("procedure", "audience") and not False:
                pass
            sc = 0.0
            dl = len(toks) or 1
            for w in set(q_stems):
                tf = toks.count(w)
                if not tf:
                    continue
                idf = math.log((self.N - self.df[w] + 0.5) / (self.df[w] + 0.5) + 1)
                sc += idf * tf * 2.2 / (tf + 1.2 * (0.25 + 0.75 * dl / self.avg))
            if sc > 0:
                scored.append((sc, s, k))
        scored.sort(key=lambda x: -x[0])
        out, seen = [], set()
        for sc, s, k in scored:
            key = norm(s["fields"][k])
            if key in seen:
                continue
            seen.add(key)
            out.append((sc, s, k))
            if len(out) >= topn:
                break
        return out


# --------------------------------------------------------------------------
# 3. Resolve question -> plan
# --------------------------------------------------------------------------
def svc_of(svcs, doc, sit):
    for s in svcs:
        if s["doc"] == doc and s["sit"] == sit:
            return s
    return None


def fields_for(intents):
    keys = []
    for i in intents:
        for k in INTENT_FIELDS[i]:
            if k not in keys:
                keys.append(k)
    return keys or list(DEFAULT_FIELDS)


def same_across(svcs_list, keys):
    return all(len({norm(s["fields"].get(k, "")) for s in svcs_list}) == 1 for k in keys)


def make_plan(question, svcs, index, state):
    """Return dict(kind=answer|clarify|oos, contexts=[(svc,key)], pairs, note)."""
    d = detect(question)
    pairs, intents = list(d["pairs"]), d["intents"]
    prev = state.get("pairs", [])

    # ---- out of scope: unknown subject ------------------------------------
    cov = [w for w in d["content"] if w in index.vocab]
    n_c = len(d["content"])
    thr = 0.0 if prev else 0.5
    if n_c and not d["docs"] and (len(cov) / n_c < thr or (prev and not cov and n_c >= 2)):
        return {"kind": "oos", "contexts": [], "pairs": []}

    # ---- conversation: inherit missing parts ------------------------------
    if not pairs and prev:
        pairs = list(prev)
    else:
        fixed = []
        for dd, ss in pairs:
            if dd and not ss:
                inh = [p for p in prev if p[0] == dd and p[1]]
                fixed += inh if inh else [(dd, None)]
            elif ss and not dd:
                inh = list(dict.fromkeys((p[0], ss) for p in prev if p[0]))
                fixed += inh if inh else [(None, ss)]
            else:
                fixed.append((dd, ss))
        pairs = list(dict.fromkeys(fixed))

    # ---- no service words at all -> topic search ---------------------------
    if not pairs:
        q_st = [w for w in stems(d["q"]) if w not in STOP and len(w) >= 3]
        hits = index.search(q_st)
        if not hits or hits[0][0] < 2.0:
            return {"kind": "oos", "contexts": [], "pairs": []}
        ctxs = [(s, k) for _, s, k in hits[:3]]
        return {"kind": "answer", "contexts": ctxs, "pairs": list({(s["doc"], s["sit"]) for s, _ in ctxs})}

    keys = fields_for(intents)
    resolved, need = [], None
    for dd, ss in pairs:
        if dd and ss:
            resolved.append((dd, ss))
        elif dd:                                    # document known, situation unknown
            group = [svc_of(svcs, dd, x) for x in SITS]
            if same_across(group, keys):
                resolved.append((dd, "renewal"))
            else:
                q_st = [w for w in d["content"] if w in index.vocab]
                hits = index.search(q_st, allowed_docs={dd}) if q_st else []
                if hits and hits[0][0] >= 2.5:
                    ctxs = [(s, k) for _, s, k in hits[:3]]
                    return {"kind": "answer", "contexts": ctxs, "pairs": list({(s["doc"], s["sit"]) for s, _ in ctxs})}
                need = ("sit", dd)
        else:                                       # situation known, document unknown
            group = [svc_of(svcs, x, ss) for x in DOC_NAME]
            if same_across(group, keys):
                resolved.append(("passport", ss))
            else:
                need = ("doc", ss)
    if need and not resolved:
        return {"kind": "clarify", "need": need, "contexts": [], "pairs": []}

    ctxs, seen = [], set()
    multi = len(resolved) > 1
    use_keys = keys if not (multi and not intents) else ["fees", "docs"]
    for dd, ss in resolved:
        s = svc_of(svcs, dd, ss)
        if not s:
            continue
        for k in use_keys:
            v = s["fields"].get(k)
            if not v or (k == "notes" and norm(v) in ("لا يوجد", "")):
                continue
            sig = (norm(v), )
            if sig in seen:
                continue
            seen.add(sig)
            ctxs.append((s, k))
    # size guard: drop the least important fields first
    def total():
        return sum(len(ctx_text(s, k)) for s, k in ctxs)
    for drop in ("audience", "conditions", "time", "places", "notes"):
        while total() > MAX_CTX_CHARS and any(k == drop for _, k in ctxs):
            idx = max(i for i, (_, k) in enumerate(ctxs) if k == drop)
            ctxs.pop(idx)
    return {"kind": "answer", "contexts": ctxs, "pairs": resolved}


# --------------------------------------------------------------------------
# 4. Model
# --------------------------------------------------------------------------
SYSTEM = """أنت مساعد دائرة الأحوال المدنية والجوازات الأردنية. أجب بالعربية وبإيجاز من «النصوص المرجعية» فقط.
- اختصر: من جملة إلى ثلاث جمل (إلا القوائم). أجب عن كل ما سُئل، وانقل الأرقام والمبالغ والمدد كما وردت.
- القوائم (وثائق/شروط) اذكرها كاملة.
- الرسوم تتبع حالة السائل (العمر، انتهاء الصلاحية، داخل/خارج الأردن، عدد مرات الفقدان): اذكر الرسم المنطبق مع شرطه وراجع الملاحظات.
- في المقارنة اذكر قيمة كل خدمة ثم النتيجة. صحّح أي افتراض خاطئ.
- إن لم تجد الجواب قل إنه غير متوفر ولا تخمّن."""

SYS_REFUSE = """أنت مساعد جوازات وأحوال مدنية أردني (جواز السفر، دفتر العائلة، البطاقة الذكية). السؤال خارج هذه الخدمات: اعتذر بجملة واحدة بأنك لا تملك معلومات عنه، واذكر الخدمات التي تساعد بها. لا تعطِ أي معلومة أو رقم عنه."""

SYS_CLARIFY = """سؤال المستخدم ناقص التحديد. اكتب سؤالاً توضيحياً واحداً قصيراً بالعربية يعرض الخيارات المذكورة. لا تجب عن السؤال ولا تذكر أرقاماً."""


def ollama_chat(system, user, num_predict=450, retries=1):
    body = {"model": MODEL, "stream": False, "keep_alive": "30m",
            "messages": [{"role": "system", "content": system}, {"role": "user", "content": user}],
            "options": {"temperature": 0, "top_p": 0.9, "num_ctx": NUM_CTX, "num_thread": os.cpu_count() or 4, "num_predict": num_predict}}
    last = None
    for attempt in range(retries):
        try:
            req = urllib.request.Request(OLLAMA + "/api/chat", data=json.dumps(body).encode("utf-8"),
                                         headers={"Content-Type": "application/json"})
            with urllib.request.urlopen(req, timeout=600) as r:
                txt = json.loads(r.read().decode("utf-8"))["message"]["content"]
            txt = re.sub(r"<think>.*?</think>", "", txt, flags=re.S)
            txt = re.sub(r"[\u3040-\u30ff\u3400-\u9fff\uac00-\ud7af]+", "", txt).strip()
            if txt:
                return txt
        except Exception as e:           # noqa
            last = e
            time.sleep(1.5)
    raise RuntimeError(f"ollama failed: {last}")


def pick_model():
    global MODEL
    try:
        with urllib.request.urlopen(OLLAMA + "/api/tags", timeout=10) as r:
            names = [m["name"] for m in json.loads(r.read().decode())["models"]]
        if MODEL not in names:
            alt = [n for n in names if n.startswith("command-r7b-arabic")]
            if alt:
                MODEL = alt[0]
        print("model:", MODEL, flush=True)
    except Exception as e:               # noqa
        print("WARNING: cannot list ollama models:", e, file=sys.stderr, flush=True)


def clarify_options(need):
    kind, val = need
    if kind == "sit":
        return f"المستخدم سأل عن {DOC_NAME[val]} دون أن يحدد الحالة. الخيارات: " + "، ".join(
            f"{DOC_NAME[val]} {SIT_NAME[s]}" for s in SITS)
    return f"المستخدم سأل عن خدمة ({SIT_NAME[val]}) دون أن يحدد الوثيقة. الخيارات: " + "، ".join(DOC_NAME.values())


def fallback_clarify(need):
    kind, val = need
    if kind == "sit":
        return f"أي خدمة تقصد بخصوص {DOC_NAME[val]}: لأول مرة، تجديد، بدل فاقد، أم بدل تالف؟"
    return f"أي وثيقة تقصد ({SIT_NAME[val]}): جواز السفر، دفتر العائلة، أم البطاقة الذكية؟"


FALLBACK_OOS = ("عذراً، لا تتوفر لدي معلومات عن هذا الموضوع. أستطيع المساعدة في خدمات جواز السفر "
                "ودفتر العائلة والبطاقة الذكية فقط.")
NEG = re.compile(r"غير متوفر|لا تتوفر|لا توجد (?:لدي )?معلومات|لا أملك|لا يوجد في النص|غير مذكور")


def answer_message(question, history, svcs, index, state):
    plan = make_plan(question, svcs, index, state)
    kind = plan["kind"]
    if kind == "oos":
        try:
            a = ollama_chat(SYS_REFUSE, f"سؤال المستخدم: {question}", 45)
        except Exception:
            a = FALLBACK_OOS
        return a, []
    if kind == "clarify":
        try:
            a = ollama_chat(SYS_CLARIFY, f"سؤال المستخدم: {question}\n{clarify_options(plan['need'])}", 45)
        except Exception:
            a = fallback_clarify(plan["need"])
        return a, []

    ctx_list = [ctx_text(s, k) for s, k in plan["contexts"]]
    state["pairs"] = [p for p in plan["pairs"] if p[0] and p[1]] or state.get("pairs", [])
    titles = list(dict.fromkeys(s["title"] for s, _ in plan["contexts"]))
    block = "\n".join(f"[{i}] {c}" for i, c in enumerate(ctx_list, 1))
    hist = f"\nالسؤال السابق في المحادثة: {history[-1]}" if history else ""
    user = f"النصوص المرجعية:\n{block}\n{hist}\n\nالسؤال: {question}\nالإجابة:"
    try:
        ans = ollama_chat(SYSTEM, user, 170)
    except Exception as e:
        print("LLM error:", e, file=sys.stderr, flush=True)
        ans = " ".join(c.split(": ", 1)[-1] for c in ctx_list[:2])[:700]
    if len(ans) < 220 and NEG.search(ans):
        return ans, []
    return ans, ctx_list


# --------------------------------------------------------------------------
# 5. Entry point
# --------------------------------------------------------------------------
def main():
    if len(sys.argv) != 2:
        sys.exit("Usage: python main.py questions.json")
    data = json.loads(Path(sys.argv[1]).read_text(encoding="utf-8-sig"))
    svcs = load_services()
    index = Index(svcs)
    pick_model()
    try:                                  # load the model into RAM once, before the timed questions
        ollama_chat(SYSTEM, "مرحبا", 2, retries=1)
    except Exception:
        pass
    out_path = ROOT / "answers.json"
    if Path(sys.argv[1]).resolve().parent != ROOT:
        out_path = Path(sys.argv[1]).resolve().parent / "answers.json"
    result = {"chats": []}
    for chat in data.get("chats", []):
        new_chat = {**{k: v for k, v in chat.items() if k != "messages"}, "messages": []}
        result["chats"].append(new_chat)
        history, state = [], {}
        for msg in chat.get("messages", []):
            q = msg.get("question", "")
            t0 = time.time()
            try:
                ans, ctxs = answer_message(q, history, svcs, index, state)
            except Exception as e:       # never lose a message
                print("ERROR", msg.get("message_id"), e, file=sys.stderr, flush=True)
                ans, ctxs = "عذراً، حدث خطأ أثناء معالجة السؤال.", []
            new_chat["messages"].append({**msg, "answer": ans, "contexts": ctxs})
            history.append(q)
            out_path.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
            print(f"{msg.get('message_id')} [{time.time() - t0:.1f}s] {ans[:90]!r}", flush=True)
    out_path.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    print("saved", out_path)


if __name__ == "__main__":
    main()