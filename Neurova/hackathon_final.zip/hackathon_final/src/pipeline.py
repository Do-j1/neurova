"""
=============================================================================
🤖 خط أنابيب المساعد الذكي وتوليد الإجابات (RAG Generation Pipeline)
=============================================================================
الوظائف الأساسية:
1. اختيار أفضل نموذج محلي متاح في Ollama تلقائياً (مثل qwen2.5:7b أو qwen2.5:3b).
2. إعداد صياغة هندسية محكمة للبرومبت (System Prompt) تمنع الهلوسة منعاً باتاً.
3. دمج المقاطع المسترجعة مع توثيق المصدر ورقم الصفحة.
4. قياس زمن الاستجابة (Latency) لكل مرحلة لمساعدة الفريق في التحليل.
5. التحقق الصارم من توفر المعلومة وإرجاع الصيغة الرسمية المعتمدة عند غيابها.
=============================================================================
"""

import os
import time
import ollama

from src.search import retrieve, get_indexed_summary


# =============================================================================
# ⚙️ إعدادات النموذج المعتمد للمسابقة (Official Hackathon Model Configuration)
# =============================================================================
# يتم اعتماد نموذج المسابقة الرسمي (فئة 7B) بشكل صريح ومحدد
# يمكن للمنظمين تغيير اسم النموذج عبر متغير البيئة HACKATHON_MODEL دون تعديل الكود
OFFICIAL_HACKATHON_MODEL = os.getenv("HACKATHON_MODEL", "command-r7b-arabic:7b")
# قائمة النماذج الاحتياطية المسموحة في حال التشغيل التجريبي على أجهزة محدودة
FALLBACK_LOCAL_MODELS = [
    "qwen2.5:7b",
    "qwen2.5:3b",
    "llama3.1:8b",
    "mistral",
]


def get_available_models() -> list[str]:
    """
    استكشاف قائمة نماذج المحادثة والتوليد المثبتة محلياً في خادم Ollama.
    ملاحظة: يتم استبعاد نموذج التضمين bge-m3 لأنه مخصص للبحث فقط وليس للتوليد.
    """
    try:
        models_data = ollama.list()
        models_list = models_data.get("models", [])
        names = []
        for m in models_list:
            name = m.get("model") if isinstance(m, dict) else getattr(m, "model", None)
            if not name:
                name = m.get("name") if isinstance(m, dict) else getattr(m, "name", "")
            # استبعاد نماذج التضمين الدلالي
            if name and not any(emb in name.lower() for emb in ["bge", "embed", "nomic"]):
                names.append(name)
        return names
    except Exception:
        return []


def select_best_model(preferred_model: str = None) -> str:
    """
    تحديد نموذج التوليد المعتمد للمشروع بدقة:
    1. الأولوية القصوى للنموذج المحدد صراحة (عبر سطر الأوامر أو الواجهة أو HACKATHON_MODEL).
    2. فحص تواجد النموذج الرسمي في خادم Ollama المحلي.
    3. في حال عدم تثبيت النموذج الرسمي على الجهاز، يتم التحويل تلقائياً لأقرب نموذج محلي
       مع طباعة تنبيه رسمي لتوجيه المستخدم لتحميل النموذج المطلوب.
    """
    target = preferred_model or os.getenv("HACKATHON_MODEL") or OFFICIAL_HACKATHON_MODEL
    available = get_available_models()

    # إذا كان النموذج المطلوب مثبتاً محلياً، يتم اعتماده فوراً
    if target in available or any(target in m for m in available):
        matched = target if target in available else [m for m in available if target in m][0]
        return matched

    # في حال لم يتم العثور على النموذج الرسمي المحدد
    if available:
        # البحث عن أقرب نموذج محلي متاح
        fallback = available[0]
        for candidate in FALLBACK_LOCAL_MODELS:
            for av in available:
                if candidate in av:
                    fallback = av
                    break
            if fallback != available[0]:
                break

        return fallback

    # إذا لم يكن هناك اتصال بـ Ollama بعد
    return target


# الصياغة الهندسية الصارمة للموجه (System Prompt) - مفتاح الفوز في سيناريوهات عدم الهلوسة
REFUSAL = "المعلومة غير متوفرة في المستندات المرفقة."
SYSTEM_PROMPT = """أنت مساعد ذكي متخصص في الخدمات الحكومية.

مهمتك الإجابة عن الأسئلة باستخدام النصوص المرجعية المقدمة فقط.

القواعد:
1. أجب بالعربية فقط، بشكل مختصر ودقيق.
2. اعتمد حصرياً على المعلومات الموجودة في النصوص المرجعية.
3. إذا كانت المعلومة غير مذكورة، أجب حرفياً:
المعلومة غير متوفرة في المستندات المرفقة.
4. إذا تضمن السؤال رقماً أو معلومة خاطئة، وكانت القيمة الصحيحة
مذكورة في الوثائق، صححها بوضوح ولا ترفض السؤال.
5. لا تعتبر اختلاف الرقم المذكور في السؤال عن الرقم الموجود
في الوثائق دليلاً على عدم توفر المعلومة.
6. عند المقارنة بين مدد الإنجاز، المدة الأقل تعني الخدمة الأسرع.
7. لا تخترع أي رسوم أو شروط أو معلومات غير موجودة.
8. لا تذكر أسماء الملفات داخل الإجابة.
قواعد المقارنة:
- إذا سُئلت أي خدمة أسرع، استخرج مدة إنجاز كل خدمة من النص المرجعي أولاً.
- قارن المدد بعد توحيد الوحدات.
- الخدمة ذات المدة الأقل هي الأسرع.
- إذا كانت مدة خدمة 3 أيام ومدة خدمة أخرى يوم واحد، فالخدمة التي تستغرق يوماً واحداً هي الأسرع.
- تحقق من صحة المقارنة قبل كتابة الإجابة النهائية.
- إذا كانت مدة إحدى الخدمتين غير مذكورة، لا تخترعها ولا تحدد أيهما أسرع.
- اكتب الإجابة النهائية باللغة العربية فقط.
- لا تستخدم أحرفاً صينية أو أي نص بلغة أخرى.
- لا تعرض خطوات تفكيرك أو تعليقاً على اللغة المستخدمة.
- أعطِ الإجابة النهائية مباشرة دون مقدمات.

أمثلة توضيحية:

مثال 1:
النص: رسوم تجديد جواز السفر 20 دينار.
السؤال: هل رسوم تجديد جواز السفر 35 دينار؟
الإجابة: لا، رسوم تجديد جواز السفر هي 20 دينار.

مثال 2:
النص: رسوم تجديد جواز السفر 20 دينار.
السؤال: هل يمكن تجديد جواز السفر إلكترونياً؟
الإجابة: المعلومة غير متوفرة في المستندات المرفقة.

تحقق من النص المرجعي قبل الإجابة.
"""


def build_context_block(chunks: list[dict]) -> str:
    """
    تنسيق وترتيب المقاطع المسترجعة ضمن قالب سياق واضح للنموذج اللغوي (LLM)،
    مع توضيح اسم كل مستند ورقم الصفحة المقابلة له.
    """
    context_parts = []
    for idx, c in enumerate(chunks, 1):
        source = c.get("source", "مستند رسمي")
        page = c.get("page", 0)
        page_info = f"صفحة {page}" if page else "بدون رقم صفحة"
        text = c.get("text", "").strip()

        part = f"--- [المستند {idx}: {source} | {page_info}] ---\n{text}"
        context_parts.append(part)

    return "\n\n".join(context_parts)


def answer_question(
    question: str,
    model: str = None,
    k: int = 4,
    max_distance: float = 0.75,
    use_hybrid: bool = True,
) -> dict:
    """
    خط الأنابيب الكامل لمعالجة السؤال وتوليد الإجابة (Complete RAG Pipeline):
    1. التحقق من صلاحية السؤال ووجود بيانات مفهرسة.
    2. الاسترجاع الهجين للمقاطع الأكثر صلة (Semantic + BM25).
    3. فلترة النتائج بالاعتماد على سقف المسافة الدلالية لمنع الهلوسة مبكراً.
    4. تجميع السياق وتمريره مع السؤال إلى نموذج Ollama المحلي.
    5. قياس زمن المعالجة (Latency) والتحقق من صحة النتائج والمصادر.

    المخرجات:
    قاموس يحتوي على:
    - answer: الإجابة النصية المولدة.
    - sources: قائمة المصادر المستند إليها مع رقم الصفحة ونسبة التطابق.
    - enough_info: علامة منطقية تشير إلى ما إذا كانت المعلومة متوفرة في المستندات.
    - model_used: اسم النموذج الذي قام بالتوليد.
    - latency: الزمن المستغرق بالثواني.
    """
    t_start = time.time()
    clean_q = question.strip()

    if not clean_q:
        return {
            "answer": "الرجاء إدخال سؤال صالح للبحث.",
            "sources": [],
            "enough_info": False,
            "model_used": "none",
            "latency": 0.0,
        }

    # 1. التحقق من وجود مستندات في قاعدة البيانات
    summary = get_indexed_summary()
    if summary["total_chunks"] == 0:
        return {
            "answer": "لا توجد مستندات معالجة في قاعدة البيانات بعد. يرجى فهرسة المستندات أولاً.",
            "sources": [],
            "enough_info": False,
            "model_used": "none",
            "latency": round(time.time() - t_start, 3),
        }

    # 2. الاسترجاع الهجين للمقاطع الأكثر صلة
    retrieved_chunks = retrieve(
        clean_q,
        k=k,
        max_distance=max_distance,
        use_hybrid=use_hybrid,
    )

    # إذا لم يسترجع أي مقطع ضمن سقف المسافة، نرفض السؤال فوراً لمنع الهلوسة
    if not retrieved_chunks:
        return {
            "answer": REFUSAL,
            "sources": [],
            "enough_info": False,
            "model_used": "none",
            "latency": round(time.time() - t_start, 3),
        }

    # إعداد قائمة المصادر الفريدة للمقاطع التي أُرسلت للنموذج
    sources = []
    seen = set()
    for c in retrieved_chunks:
        key = (c["source"], c["page"])
        if key not in seen:
            seen.add(key)
            sources.append({
                "source": c["source"],
                "page": c["page"],
                "distance": round(c.get("distance", 0.0), 4),
                "rrf_score": c.get("rrf_score", 0.0),
                "text": c["text"],
            })

    # 3. بناء السياق الموجه للنموذج
    context = build_context_block(retrieved_chunks)

    user_prompt = f"""المقتطفات المرجعية:
{context}

السؤال المطلوب الإجابة عنه:
{clean_q}

الإجابة المختصرة على السؤال فقط:"""

    chosen_model = select_best_model(model)

    # 4. استدعاء النموذج اللغوي المحلي عبر Ollama
    try:
        response = ollama.chat(
            model=chosen_model,
            messages=[
                {"role": "system", "content": SYSTEM_PROMPT},
                {"role": "user", "content": user_prompt},
            ],
            options={
                "temperature": 0.1,  # درجة حرارة منخفضة جداً لضمان الدقة ومنع أي ابتكار
                "top_p": 0.85,
                "num_predict": 300,
            },
        )
        answer_text = response["message"]["content"].strip()
    

        # رصد إشارات غياب المعلومة في مخرجات النموذج
        negative_signals = [
            "المعلومة غير متوفرة",
            "غير متوفرة في المستندات",
            "لا تحتوي المستندات",
            "لم يرد في المستندات",
            "لا يتضمن السياق",
            "غير مذكور في السياق",
            "لم تذكر المستندات",
        ]
        enough_info = bool(answer_text) and not any(sig in answer_text for sig in negative_signals)
        if not enough_info:
            answer_text = REFUSAL

        return {
            "answer": answer_text,
            "sources": sources if enough_info else [],
            "enough_info": enough_info,
            "model_used": chosen_model,
            "latency": round(time.time() - t_start, 3),
        }

    except Exception as e:
        err_msg = str(e)
        if "not found" in err_msg.lower():
            suggested = f"النموذج '{chosen_model}' غير محمل في خادم Ollama. يرجى تشغيل الأمر: ollama pull {chosen_model}"
        else:
            suggested = f"حدث خطأ أثناء التواصل مع خادم Ollama المحلي: {err_msg}"

        return {
            "answer": suggested,
            "sources": [],
            "enough_info": False,
            "model_used": chosen_model,
            "error": err_msg,
            "latency": round(time.time() - t_start, 3),
        }
