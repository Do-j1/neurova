"""
=============================================================================
🏛️ وحدة استخراج ومعالجة النصوص والمستندات الحكومية (Arabic Document Ingestion)
=============================================================================
الوظائف الأساسية:
1. تنظيف وتطبيع النصوص العربية المستخرجة من ملفات PDF و TXT.
2. معالجة عيوب التشفير الشائعة في ملفات الـ PDF العربية (مثل تشابك الحروف، والهمزات المنفصلة).
3. تقطيع ذكي للنصوص (Chunking) مع الحفاظ على ترابط الجمل، والفقرات، والنقاط التعدادية (Bullet Points).
4. توثيق وحفظ أرقام الصفحات بدقة لإسناد المصادر (Source Citations).
=============================================================================
"""

from pathlib import Path
import pymupdf
import re


# خريطة تحويل الأرقام العربية المشرقية (٠-٩) إلى الأرقام القياسية (0-9)
# لضمان تطابق أرقام الرسوم والمدد الزمنية سواء كتبت بالعربية أو الإنجليزية
EASTERN_TO_WESTERN_DIGITS = str.maketrans("٠١٢٣٤٥٦٧٨٩", "0123456789")


def clean_arabic_text(text: str) -> str:
    """
    تنظيف وتطبيع النصوص العربية المستخرجة من ملفات الـ PDF والمستندات الحكومية.

    المعالجات المطبقة:
    - إزالة الأحرف غير المرئية والمسافات الصفرية (Zero-width characters) والمسافات غير القابلة للكسر.
    - إزالة حركات التشكيل (التنوين، الفتحة، الضمة، الكسرة، الشدة، السكون) لتوحيد البحث الدلالي.
    - إزالة التطويل / الكشيدة (ـ).
    - تصحيح مشكلة تداخل حروف الألف والهمزة الناتجة عن محركات الـ PDF (Ligatures):
      مثال: "األ" تصبح "الأ" ، "اإل" تصبح "الإ".
    - إعادة ربط الهمزة المتطرفة المفصولة بمسافة خاطئة (مثل: "زمال ء" -> "زملاء").
    - إعادة ربط (الـ) التعريف المفصولة بمسافة في بعض خطوط الـ PDF (مثل: "الـ معلم" أو "ال خدمة").
    - توحيد الأرقام المشرقية مع الأرقام القياسية لتسهيل مطابقة رسوم الخدمات وشروط الأعمار.
    - تنظيم المسافات والفواصل والأسطر الفارغة المتتالية.
    """
    if not text:
        return ""

    # 1. إزالة المحارف المخفية ومحارف التوجيه الخاصة (Zero-width & Non-breaking spaces)
    text = re.sub(r"[\u200B-\u200F\uFEFF\u00A0]", " ", text)

    # 2. إزالة حركات التشكيل العربية (Tashkeel)
    # تشمل: الفتح، الضم، الكسر، التنوين، الشدة، والسكون
    text = re.sub(r"[\u064B-\u065F\u0670]", "", text)

    # 3. إزالة التطويل أو الكشيدة (Kashida)
    text = re.sub(r"\u0640", "", text)

    # 4. تصحيح تداخلات الألف واللام والهمزة الناتجة عن فك تشفير خطوط الـ PDF
    text = re.sub(r"األ", "الأ", text)
    text = re.sub(r"اإل", "الإ", text)
    text = re.sub(r"اآل", "الآ", text)

    # 5. تصحيح الهمزة المتطرفة المنفصلة بمسافة ناتجة عن استخراج الـ PDF
    # مثال: "أدلة و شواهد أثنا ء التقديم" -> "أثناء"
    text = re.sub(r"(\w)\s+ء\b", r"\1ء", text)

    # 6. تصحيح مسافات "الـ" التعريف المفصولة عن الكلمة
    # مثال: "ال خدمة" -> "الخدمة" عندما تتبع بحرف عربي
    text = re.sub(r"\bال\s+([\u0621-\u064A]{3,})\b", r"ال\1", text)

    # 7. توحيد الأرقام المشرقية (٠-٩) إلى أرقام عربية قياسية (0-9)
    # لضمان تطابق رسوم الخدمات وأرقام المواد القانونية
    text = text.translate(EASTERN_TO_WESTERN_DIGITS)

    # 8. تصحيح الأقواس المعكوسة الناتجة عن اتجاه اليمين-إلى-اليسار (RTL) في الـ PDF
    # مثل: ")إن وجدت(" تصبح "(إن وجدت)"
    text = re.sub(r"\)\s*([^()]+)\s*\(", r"(\1)", text)

    # 9. ضغط المسافات وعلامات التبويب المتتالية إلى مسافة واحدة
    text = re.sub(r"[ \t]+", " ", text)

    # 10. تنظيم الفواصل والأسطر المتتالية الزائدة
    text = re.sub(r"\n\s*\n+", "\n\n", text)

    return text.strip()


def normalize_arabic_for_search(text: str) -> str:
    """
    تطبيع مخصص لمطابقة الكلمات المفتاحية (Keyword Matching / BM25):
    - توحيد جميع أشكال الألف (أ، إ، آ، ٱ) إلى ألف مجردة (ا).
    - توحيد الياء والياء المقصورة (ي، ى) إلى (ي).
    - توحيد التاء المربوطة والهاء (ة، ه) في نهايات الكلمات لتفادي الأخطاء الإملائية الشائعة.
    يستخدم هذا التطبيع في المقارنة والبحث فقط دون تغيير النص الأصلي المحفوظ.
    """
    if not text:
        return ""
    text = clean_arabic_text(text)
    # توحيد الألفات
    text = re.sub(r"[أإآٱ]", "ا", text)
    # توحيد التاء المربوطة والهاء في نهاية الكلمة
    text = re.sub(r"ة\b", "ه", text)
    # توحيد الياء المقصورة والياء العادية
    text = re.sub(r"ى\b", "ي", text)
    return text.lower()


def read_file(path: str | Path) -> list[tuple[int, str]]:
    """
    قراءة الملفات (PDF أو TXT) واستخراج النصوص مع التوثيق برقم الصفحة.

    المخرجات:
    - بالنسبة لملفات PDF: قائمة أزواج (رقم الصفحة [يبدأ من 1]، نص الصفحة النظيف).
    - بالنسبة لملفات TXT: قائمة تحتوي على زوج واحد (0، نص الملف النظيف).

    الاستثناءات:
    - FileNotFoundError إذا كان الملف غير موجود.
    - ValueError إذا كان الامتداد غير مدعوم.
    """
    p = Path(path)

    if not p.exists():
        raise FileNotFoundError(f"لم يتم العثور على الملف المحدد: {p}")

    # معالجة ملفات PDF عبر PyMuPDF
    if p.suffix.lower() == ".pdf":
        pages = []
        with pymupdf.open(p) as doc:
            for page_number, page in enumerate(doc, start=1):
                raw_text = page.get_text()
                cleaned_text = clean_arabic_text(raw_text)

                if not cleaned_text:
                    # تحذير لطيف في حال كانت الصفحة فارغة أو ممسوحة ضوئياً كصورة
                    print(
                        f"تنبيه: المستند {p.name}، الصفحة {page_number} "
                        "لا تحتوي على نصوص قابلة للاستخراج."
                    )
                    continue

                pages.append((page_number, cleaned_text))

        return pages

    # معالجة الملفات النصية TXT
    if p.suffix.lower() == ".txt":
        raw_text = p.read_text(encoding="utf-8", errors="replace")
        cleaned_text = clean_arabic_text(raw_text)

        if not cleaned_text:
            print(f"تنبيه: المستند النصي {p.name} فارغ.")

        return [(0, cleaned_text)] if cleaned_text else []

    raise ValueError(f"نوع الملف غير مدعوم: {p.suffix} (المدعوم: .pdf, .txt)")


def chunk_text(
    pages: list[tuple[int, str]],
    chunk_size: int = 650,
    overlap: int = 120,
) -> list[tuple[int, str]]:
    """
    تقطيع النصوص إلى مقاطع دلالية متداخلة (Overlapping Semantic Chunks).

    المبادئ الهندسية المتبعة في التقطيع:
    1. الحفاظ على علامات الترقيم ونهايات الجمل العربية (. ، ؟ ! ؛) كنقاط فصل رئيسية.
    2. الحفاظ على البنود والشروط التعدادية (مثل: 1. ، 2. ، - ، •) وعدم بتر الشروط في المنتصف.
    3. توفير تداخل (Overlap) كافٍ لضمان عدم فقدان السياق بين بداية ونهاية كل مقطع.
    4. ربط كل مقطع برقم صفحته الأصلية لضمان التوثيق الدقيق (Source Citations).

    المعاملات:
    - pages: قائمة أزواج (رقم الصفحة، النص).
    - chunk_size: الحد الأقصى التقريبي لعدد الأحرف في كل مقطع (افتراضياً 650 حرفاً، مثالي للخدمات الحكومية).
    - overlap: عدد أحرف التداخل لضمان الترابط الدلالي (افتراضياً 120 حرفاً).
    """
    if chunk_size <= 0:
        raise ValueError("يجب أن يكون chunk_size رقماً موجباً أكبر من الصفر.")

    if overlap < 0 or overlap >= chunk_size:
        raise ValueError("يجب أن تكون قيمة overlap بين 0 و chunk_size - 1.")

    chunks = []

    for page_number, text in pages:
        # تنظيم المسافات الداخلية مع الحفاظ على ترابط الجمل
        text = re.sub(r"[ \t]+", " ", text).strip()

        if not text:
            continue

        start = 0
        total_len = len(text)

        while start < total_len:
            end = min(start + chunk_size, total_len)

            # إذا لم نصل إلى نهاية النص، نبحث عن أقرب فاصل جمل طبيعي
            if end < total_len:
                best_break = -1

                # قائمة فواصل الجمل العربية المرتبة حسب الأولوية
                arabic_sentence_puncts = [
                    "\n\n",   # نهاية فقرة كاملة
                    "\n- ",   # بداية بند تعدادي
                    "\n• ",   # بداية نقطة
                    ". ",     # نهاية جملة
                    "؟ ",     # نهاية سؤال
                    "؛ ",     # فاصلة منقوطة
                    "، ",     # فاصلة عربية
                    "\n",     # سطر جديد
                ]

                # البحث عن فاصل في النصف الثاني من المقطع لتجنب المقاطع القصيرة جداً
                min_split_point = start + (chunk_size // 2)
                for punct in arabic_sentence_puncts:
                    idx = text.rfind(punct, min_split_point, end)
                    if idx != -1:
                        best_break = max(best_break, idx + len(punct))
                        break

                if best_break != -1:
                    end = best_break
                else:
                    # في حال عدم وجود علامات ترقيم، نفصل عند حدود كلمة
                    boundary = text.rfind(" ", min_split_point, end)
                    if boundary > start:
                        end = boundary

            chunk = text[start:end].strip()

            if chunk:
                chunks.append((page_number, chunk))

            if end >= total_len:
                break

            # حساب بداية المقطع التالي مع التداخل (Overlap)
            start = max(start + 1, end - overlap)

            # الانتقال إلى بداية الكلمة التالية لتفادي بدء المقطع من منتصف كلمة
            while start < total_len and text[start] != " ":
                start += 1
            if start < total_len:
                start += 1

    return chunks


def ingest_file(path: str | Path) -> int:
    """
    دالة مساعدة تربط استخراج الملف بفهرسته مباشرة في قاعدة البيانات المتجهة (ChromaDB).
    تتيح استيراداً سلساً من كلا المجلدين ingest و search دون حدوث Circular Import.
    """
    from src.search import ingest_file as _ingest_file
    return _ingest_file(path)
